Configuration WebServer
{
  param 
  ( 
    # Target nodes to apply the configuration 
    [string[]]$NodeName = "localhost"
  ) 

  Import-DscResource -ModuleName xWebAdministration
  
  Node $NodeName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure 	= "Present"
      Name 		= "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure 	= "Present"
      Name 		= "Web-Asp-Net45"
	  DependsOn = "[WindowsFeature]IIS"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name 		= "Web-Mgmt-Console"
        Ensure 		= "Present"
	    DependsOn 	= "[WindowsFeature]IIS"
    }
	
    # Stop the default website
    xWebsite DefaultSite 
    {
        Ensure          = "Present"
        Name            = "Default Web Site"
        State           = "Stopped"
        PhysicalPath    = "C:\inetpub\wwwroot"
        DependsOn       = "[WindowsFeature]IIS"
    }
  }
} 