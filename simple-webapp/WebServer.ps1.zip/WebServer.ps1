Configuration WebServer
{
  param 
  ( 
    # Target nodes to apply the configuration 
    [string[]]$NodeName = "localhost",

	# Name of the website to create 
    [Parameter(Mandatory)] 
    [ValidateNotNullOrEmpty()] 
    [String]$WebSiteName, 

    # Source Path for Website content 
    [Parameter(Mandatory)] 
    [ValidateNotNullOrEmpty()] 
    [String]$SourcePath, 

    # Destination path for Website content 
    [Parameter(Mandatory)] 
    [ValidateNotNullOrEmpty()] 
    [String]$DestinationPath   
  ) 

  Import-DscResource -ModuleName xWebAdministration
  
  Node $NodeName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure 	= "Present"
      Name 		= "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure 	= "Present"
      Name 		= "Web-Asp-Net45"
	  DependsOn = "[WindowsFeature]IIS"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name 		= "Web-Mgmt-Console"
        Ensure 		= "Present"
	    DependsOn 	= "[WindowsFeature]IIS"
    }
	
    # Stop the default website
    xWebsite DefaultSite 
    {
        Ensure          = "Present"
        Name            = "Default Web Site"
        State           = "Stopped"
        PhysicalPath    = "C:\inetpub\wwwroot"
        DependsOn       = "[WindowsFeature]IIS"
    }
    
	# Copy the website content 
    File WebContent 
    { 
        Ensure          = "Present" 
        SourcePath      = $SourcePath 
        DestinationPath = $DestinationPath 
        Recurse         = $true 
        Type            = "Directory" 
        DependsOn       = "[WindowsFeature]AspNet45" 
    }
	
    # Create a new website 
    xWebsite NewWebSite  
    { 
        Ensure          = "Present" 
        Name            = $WebSiteName 
        State           = "Started" 
        PhysicalPath    = $DestinationPath 
        DependsOn       = "[File]WebContent" 
    } 
  }
} 