Configuration WebServer
{
  param 
  ( 
    # Target nodes to apply the configuration 
    [string[]]$NodeName = "localhost"
  ) 

  Import-DscResource -ModuleName xWebAdministration
  
  Node $NodeName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure 	= "Present"
      Name 		= "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure 	= "Present"
      Name 		= "Web-Asp-Net45"
	  DependsOn = "[WindowsFeature]IIS"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name 		= "Web-Mgmt-Console"
        Ensure 		= "Present"
	    DependsOn 	= "[WindowsFeature]IIS"
    }
	
    # Stop the default website
    xWebsite DefaultSite 
    {
        Ensure          = "Present"
        Name            = "Default Web Site"
        State           = "Stopped"
        PhysicalPath    = "C:\inetpub\wwwroot"
        DependsOn       = "[WindowsFeature]IIS"
    }
    
	# Copy the website content 
    File WebContent 
    { 
        Ensure          = "Present" 
        SourcePath      = $Node.SourcePath 
        DestinationPath = $Node.DestinationPath 
        Recurse         = $true 
        Type            = "Directory" 
        DependsOn       = "[WindowsFeature]AspNet45" 
    }
	
    # Create a new website 
    xWebsite BakeryWebSite  
    { 
        Ensure          = "Present" 
        Name            = $Node.WebsiteName 
        State           = "Started" 
        PhysicalPath    = $Node.DestinationPath 
        DependsOn       = "[File]WebContent" 
    } 
  }
} 